package com.ella.offline;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.TextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private static final int REQ = 20;
    private TextView status, lastCommand;
    private View orb;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        lastCommand = findViewById(R.id.lastCommand);
        orb = findViewById(R.id.orb);
        Button start = findViewById(R.id.startButton);

        start.setOnClickListener(v -> startElla());

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.POST_NOTIFICATIONS}, REQ);
        }
    }

    private void startElla() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, REQ);
            return;
        }
        ContextCompat.startForegroundService(this, new Intent(this, EllaService.class));
        status.setText("Listening in background");
        lastCommand.setText("Say: “Ella, what time is it?”");
        pulse();
    }

    private void pulse() {
        AlphaAnimation a = new AlphaAnimation(0.45f, 1.0f);
        a.setDuration(900);
        a.setRepeatMode(AlphaAnimation.REVERSE);
        a.setRepeatCount(AlphaAnimation.INFINITE);
        orb.startAnimation(a);
    }
}
