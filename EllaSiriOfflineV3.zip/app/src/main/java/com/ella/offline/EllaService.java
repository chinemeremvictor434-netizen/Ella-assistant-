package com.ella.offline;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.hardware.camera2.CameraManager;
import android.provider.Settings;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class EllaService extends Service {
    private static final String CHANNEL = "ella_voice";
    private static final int NOTIFICATION_ID = 77;
    private volatile boolean running;
    private Thread worker;
    private Model model;
    private Recognizer recognizer;
    private AudioRecord recorder;
    private TextToSpeech tts;
    private boolean flashlightOn = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        tts = new TextToSpeech(this, s -> {
            if (s == TextToSpeech.SUCCESS) tts.setLanguage(Locale.US);
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, notification("Listening for “Ella”"));
        if (!running) {
            running = true;
            worker = new Thread(this::listen, "Ella-Vosk");
            worker.start();
        }
        return START_STICKY;
    }

    private void listen() {
        try {
            File modelDir = new File(getFilesDir(), "model");
            if (!modelDir.exists() || modelDir.list() == null || modelDir.list().length == 0)
                copyAssetFolder("model", modelDir);

            model = new Model(modelDir.getAbsolutePath());
            recognizer = new Recognizer(model, 16000.0f);

            int min = AudioRecord.getMinBufferSize(16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, 16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(min * 2, 4096));
            recorder.startRecording();

            byte[] buffer = new byte[4096];
            while (running) {
                int n = recorder.read(buffer, 0, buffer.length);
                if (n > 0 && recognizer.acceptWaveForm(buffer, n))
                    handle(recognizer.getResult());
            }
        } catch (Exception e) {
            speak("Ella could not start the offline voice engine.");
        } finally {
            releaseAudio();
        }
    }

    private void handle(String json) {
        try {
            String text = new JSONObject(json).optString("text", "")
                    .toLowerCase(Locale.US).trim();
            if (text.isEmpty()) return;

            boolean wake = text.equals("ella") || text.startsWith("ella ")
                    || text.contains(" ella ");
            if (!wake) return;

            String command = text.replaceFirst(".*?\\bella\\b", "").trim();
            if (command.isEmpty()) { speak("Yes?"); return; }
            runCommand(command);
        } catch (Exception ignored) {}
    }

    private void runCommand(String c) {
        if (c.contains("time")) {
            speak("The time is " + new SimpleDateFormat("h:mm a", Locale.US).format(new Date()));
        } else if (c.contains("date") || c.contains("today")) {
            speak("Today is " + new SimpleDateFormat("EEEE, d MMMM", Locale.US).format(new Date()));
        } else if (c.contains("battery")) {
            IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent i = registerReceiver(null, f);
            int level = i == null ? -1 : i.getIntExtra("level", -1);
            speak(level >= 0 ? "Battery is at " + level + " percent." : "I cannot read the battery.");
        } else if (c.contains("flashlight") || c.contains("torch")) {
            toggleFlashlight();
        } else if (c.contains("wifi")) {
            openSettings(Settings.ACTION_WIFI_SETTINGS);
            speak("Opening Wi-Fi settings.");
        } else if (c.contains("bluetooth")) {
            openSettings(Settings.ACTION_BLUETOOTH_SETTINGS);
            speak("Opening Bluetooth settings.");
        } else if (c.contains("volume up") || c.contains("increase volume")) {
            ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
            speak("Volume increased.");
        } else if (c.contains("volume down") || c.contains("decrease volume")) {
            ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
            speak("Volume decreased.");
        } else if (c.contains("mute")) {
            ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI);
            speak("Muted.");
        } else if (c.contains("open settings")) {
            openSettings(Settings.ACTION_SETTINGS);
            speak("Opening settings.");
        } else if (c.contains("stop") || c.contains("sleep")) {
            speak("Okay. I am going to sleep.");
            new Handler(Looper.getMainLooper()).postDelayed(this::stopSelf, 800);
        } else if (c.contains("hello") || c.equals("hi")) {
            speak("Hello. I am Ella.");
        } else {
            speak("I heard you. That command is not implemented offline yet.");
        }
    }

    private void toggleFlashlight() {
        try {
            CameraManager cm = (CameraManager)getSystemService(CAMERA_SERVICE);
            String[] ids = cm.getCameraIdList();
            if (ids.length == 0) { speak("No camera torch is available."); return; }
            flashlightOn = !flashlightOn;
            cm.setTorchMode(ids[0], flashlightOn);
            speak(flashlightOn ? "Flashlight on." : "Flashlight off.");
        } catch (Exception e) { speak("I cannot control the flashlight on this device."); }
    }

    private void openSettings(String action) {
        try {
            Intent i = new Intent(action);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {}
    }

    private void speak(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ella");
        updateNotification(text);
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, notification(text));
    }

    private Notification notification(String text) {
        Intent launch = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, launch,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL)
                .setContentTitle("Ella")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL,
                    "Ella voice assistant", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private void copyAssetFolder(String path, File dest) throws IOException {
        String[] children = getAssets().list(path);
        if (children == null || children.length == 0) throw new IOException("Missing model");
        if (!dest.exists() && !dest.mkdirs()) throw new IOException("Cannot create model folder");
        for (String child : children) {
            String src = path + "/" + child;
            File out = new File(dest, child);
            String[] nested = getAssets().list(src);
            if (nested != null && nested.length > 0) copyAssetFolder(src, out);
            else try (InputStream in = getAssets().open(src); FileOutputStream os = new FileOutputStream(out)) {
                byte[] b = new byte[8192]; int n;
                while ((n = in.read(b)) > 0) os.write(b, 0, n);
            }
        }
    }

    private void releaseAudio() {
        try { if (recorder != null) recorder.stop(); } catch (Exception ignored) {}
        try { if (recorder != null) recorder.release(); } catch (Exception ignored) {}
        recorder = null;
    }

    @Override public void onDestroy() {
        running = false;
        releaseAudio();
        try { if (recognizer != null) recognizer.close(); } catch (Exception ignored) {}
        try { if (model != null) model.close(); } catch (Exception ignored) {}
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
