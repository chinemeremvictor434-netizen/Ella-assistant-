# Ella Siri Offline V3

A lightweight Android assistant for entry-level phones.

Included:
- Offline Vosk speech recognition.
- "Ella" wake phrase.
- Android foreground microphone service for background listening.
- Siri-inspired glowing orb UI.
- Android TTS replies.
- Offline commands for time, date, battery, flashlight, volume and settings.
- GitHub Actions cloud build with the Vosk model downloaded during the build.

Important Android limitation:
A normal third-party app cannot silently control every phone function or keep a microphone open invisibly. Android requires user permissions and a visible foreground-service notification for continuous microphone use. Some hardware/settings are intentionally opened through Android's system UI.

Build:
Run the GitHub Actions workflow manually. The generated APK appears under the workflow's Artifacts section.
