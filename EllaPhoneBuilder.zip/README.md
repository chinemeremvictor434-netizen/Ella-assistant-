# Ella Phone-Only Android Builder Project

This ZIP is structured as a normal Gradle Android project for browser/cloud Android builders.

Build requirements:
- Android SDK 35
- Java 17
- Gradle 8.9+
- Android Gradle Plugin 8.7.3

Features:
- Ella Android interface
- Foreground microphone service
- Android SpeechRecognizer
- "Ella" wake phrase detection
- Text-to-speech

Note: this is not a true offline wake-word engine. SpeechRecognizer behavior depends on Android/device services.
